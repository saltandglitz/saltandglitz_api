// module.exports.shippingSchema = require("./Shipping");
module.exports.Admin = require("./admin");
module.exports.cartSchema = require('./cartItem');
module.exports.Product = require('./Product');
module.exports.User = require('./userModel')
module.exports.Uplod = require('./upload')
module.exports.wishlistSchema = require("./wishlist")