// const { Shipping } = require("../Model")

// const Create_Shipping = (data) => {
//     return Shipping.create(data)
// }

// const Get_Shipping = () => {
//     return Shipping.find()
// }

// module.exports = {
//     Create_Shipping,
//     Get_Shipping
// }