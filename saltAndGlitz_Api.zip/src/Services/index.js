
// module.exports.shipping_Services = require("./Shipping_services")
module.exports.admin_Services = require("./admin_services")
module.exports.cart_Services = require('./cartServies')
module.exports.banner_Services = require("./banner.services")