// const express = require("express")
// const { ShippingController } = require("../../Controller")

// let route = express.Router()

// route.post("/create_shipping", ShippingController.createShipping)

// module.exports = route