const { Admin } = require("../Model")

const Create_Admin = (data) => {
    return Admin.create(data)
}

const Get_Admin = async () => {
    const admins = await Admin.find(); // Fetch all admins from the database

    // Map over the admins and replace _id with admin_id
    const updatedAdmins = admins.map(admin => {
        const { _id, ...rest } = admin.toObject(); // Convert mongoose doc to plain object and remove _id
        return {
            admin_id: _id, // Replace _id with admin_id
            ...rest         // Include other fields from the admin document
        };
    });

    return updatedAdmins;
}

module.exports = {
    Create_Admin,
    Get_Admin
}