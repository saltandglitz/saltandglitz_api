
module.exports.ShippingController = require("./Shipping_controller")
module.exports.Admin_Controller = require("./admin_controller")
// module.exports.Wishlist_controller = require('./wishlistController')
module.exports.cartController = require("./cartController")
module.exports.wishlistController = require("./wishlistController")